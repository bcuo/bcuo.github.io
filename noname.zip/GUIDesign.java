import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JSeparator;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.border.EtchedBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

class ControlPanel extends JPanel 
implements ActionListener, ChangeListener
{
	// 用来显示的Panel
	DisplayPanel display;
	
	//定义按钮
	JButton btnClear;
	JButton btnCircle;
	JButton btnRect;
	JButton btnColor;
	JButton btnImage;
	JButton btnExit;

	//定义输入的框
	JTextField tfX;
	JTextField tfY;
	JTextField tfRW;
	JTextField tfH;
	//滑动条
	JSlider slider;
	
	//当前颜色
	Color color;
	
	public ControlPanel(	DisplayPanel display)
	{
		this.display = display;

		//设置布局
		this.setLayout( new GridLayout( 0, 1, 5, 5 ) );
		
		this.add( new JLabel( "X" ) );	//加入标签
		this.add( tfX = new JTextField() );//加入输入框
	
		this.add( new JLabel( "Y" ) );
		this.add( tfY = new JTextField() );

		this.add( new JLabel( "R/W" ) );
		this.add( tfRW = new JTextField() );
		
		this.add( new JLabel( "H" ) );
		this.add( tfH = new JTextField() );
	
		//加入滑动条
		this.add( slider = new JSlider(0,100));
		slider.setValue(50);
		slider.addChangeListener(this);
		
		this.add( btnRect = new JButton("Rectangle" ));
		btnRect.addActionListener(this);
		this.add( btnCircle = new JButton("Circle" ));
		btnCircle.addActionListener(this);
		this.add( btnImage = new JButton("Image" ));
		btnImage.addActionListener(this);
		this.add( new JSeparator());
		this.add( btnColor = new JButton("Color" ));
		btnColor.addActionListener(this);
		this.add( new JSeparator());
		
		this.add( btnClear = new JButton("Clear" ));
		btnClear.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if( e.getSource() == btnCircle )
		{
			try {
				int X = Integer.parseInt( tfX.getText() );
				int Y = Integer.parseInt( tfY.getText() );
				int R = Integer.parseInt( tfRW.getText() );
				display.drawCircle(X,Y,R, color);
			} catch(Exception ee) {
				
			}
		}
		else if( e.getSource() == btnClear )
		{
			display.clear();
		}
		else if( e.getSource() == btnImage )
		{
			// 选择文件
			JFileChooser jfc = new JFileChooser();  
			
	        jfc.setDialogTitle("JFileChooser");  
	        int result = jfc.showOpenDialog(this);   
	        if (result == JFileChooser.APPROVE_OPTION) {  
	        		try {
	        			String file = jfc.getSelectedFile().getAbsolutePath();
	        			Image img = ImageIO.read( new File(file) );
	        			display.displayImage( img );
	        		} catch(Exception ee ) {
	        			
	        		}
	        }
		}
		else if( e.getSource() == btnColor )
		{
			color = JColorChooser.showDialog(null, "选取颜色", null);

            if (color == null) {
                return;
            }
		}
	}

	@Override
	public void stateChanged(ChangeEvent e) 
	{
		if( e.getSource() == slider )
		{
		}
	}	
}

class DisplayPanel extends JPanel 
{
	Image img;
	ArrayList<Integer> circleX;
	ArrayList<Integer> circleY;
	ArrayList<Integer> circleR;
	ArrayList<Color> circleColor;
	
	public DisplayPanel()
	{
		init();
	}
	
	public void clear()
	{
		init();
		repaint();
	}
	public void init()
	{
		img = null;
		circleX = new ArrayList<Integer>();
		circleY = new ArrayList<Integer>();
		circleR = new ArrayList<Integer>();
		circleColor = new ArrayList<Color>();
	}
	// 画圆
	public void drawCircle(int X, int Y, int R, Color color)
	{
		circleX.add(X);
		circleY.add(Y);
		circleR.add(R);
		circleColor.add(color);
		
		repaint();
	}
	
	// 显示图片
	public void displayImage( Image img )
	{
		this.img = img;
		repaint();
	}
	
	public void paint(Graphics g)
	{
		if( img != null )
		{
			g.drawImage(img, 0, 0, this);
		}
		
		for(int i=0; i < circleX.size(); i ++)
		{
			int X = circleX.get(i);
			int Y = circleY.get(i);
			int R = circleR.get(i);
			Color c = circleColor.get(i);
			g.setColor(c);
			g.drawOval(X-R, Y-R, 2*R, 2*R);
		}
		
	}
}

public class GUIDesign {

	public static void main(String[] args) 
	{
		JFrame f = new JFrame( "GUI" );
		
		DisplayPanel display = new DisplayPanel();
		ControlPanel control = new ControlPanel(display);
		display.setBorder( new EtchedBorder() );
		control.setBorder( new EtchedBorder() );
		
		JPanel p = new JPanel();
		p.setLayout( new BorderLayout() );
		p.add(display );
		p.add( control, BorderLayout.WEST);
		f.getContentPane().add(p);
		f.setSize(1000,800);
		f.setVisible(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}
